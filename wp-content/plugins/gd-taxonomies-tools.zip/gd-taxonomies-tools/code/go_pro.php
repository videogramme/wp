<style type="text/css">
    li.gdpt-go-pro a { font-weight: bold; color: #990000 !important; }
</style>
<script type="text/javascript">
jQuery(document).ready(function() {
    jQuery("li#toplevel_page_gdtaxtools_front ul li:last").addClass("gdpt-go-pro");
});
</script>
