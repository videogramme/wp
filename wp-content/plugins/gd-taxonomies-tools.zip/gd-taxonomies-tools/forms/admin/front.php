<table>
    <tr>
        <td valign="top">
            <div class="metabox-holder">
                <?php include(GDTAXTOOLS_PATH."forms/modules/general.php"); ?>
            </div>
        </td>
        <td style="width: 20px"> </td>
        <td valign="top">
            <div class="metabox-holder">
                <?php include(GDTAXTOOLS_PATH."forms/modules/info.php"); ?>
            </div>
        </td>
    </tr>
</table>
