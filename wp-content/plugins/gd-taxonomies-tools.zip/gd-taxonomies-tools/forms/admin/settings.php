<form method="post" action="">
    <?php include GDTAXTOOLS_PATH."forms/settings/general.php"; ?>
    <input type="submit" class="inputbutton" value="<?php _e("Save Settings", "gd-taxonomies-tools"); ?>" name="gdtt_saving" style="margin-top: 10px;" />
</form>
