<div class="wrap"><div class="gdsr">
<h2 class="gdptlogopage">GD Custom Posts And Taxonomies Tools: <?php echo $page_title; ?></h2>
<?php gdtt_upgrade_notice(); ?>
