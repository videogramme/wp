<div class="wrap"><div class="gdsr">
    <div id="gdptlogo">
        <div class="gdpttitle">
            <div class="gdtitle">GD Custom Posts And Taxonomies Tools</div>
            <div class="edition <?php echo $options["edition"]; ?>"></div>
            <span><?php echo $options["version"]; ?></span>
            <div class="clear"></div>
        </div>
        <h3><?php _e("enhancing WordPress content management", "gd-taxonomies-tools"); ?></h3>
    </div>
<?php gdtt_upgrade_notice(); ?>
